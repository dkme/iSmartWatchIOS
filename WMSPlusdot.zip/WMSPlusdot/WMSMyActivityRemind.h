//
//  WMSMyActivityRemind.h
//  WMSPlusdot
//
//  Created by Sir on 14-9-20.
//  Copyright (c) 2014年 GUOGEE. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface WMSMyActivityRemind : NSObject

@property (nonatomic) BOOL openOrClose;
//@property (nonatomic) BOOL openOrClose;

@end
