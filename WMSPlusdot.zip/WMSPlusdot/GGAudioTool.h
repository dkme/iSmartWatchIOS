//
//  GGAudioTool.h
//  WMSPlusdot
//
//  Created by Sir on 14-12-18.
//  Copyright (c) 2014年 GUOGEE. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface GGAudioTool : NSObject

+ (id)sharedInstance;

- (void)playSilentSound;

@end
