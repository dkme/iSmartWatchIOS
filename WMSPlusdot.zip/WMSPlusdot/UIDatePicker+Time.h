//
//  UIDatePicker+Time.h
//  WMSPlusdot
//
//  Created by Sir on 14-11-12.
//  Copyright (c) 2014年 GUOGEE. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface UIDatePicker (Time)

- (void)setPickerDate:(NSDate *)date;

@end
