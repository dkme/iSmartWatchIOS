//
//  WMSMySportView.h
//  WMSPlusdot
//
//  Created by John on 14-8-25.
//  Copyright (c) 2014年 GUOGEE. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface WMSMySportView : UIView

- (void)setTargetSetps:(int)steps;
- (void)setSportSteps:(int)steps;

@end
