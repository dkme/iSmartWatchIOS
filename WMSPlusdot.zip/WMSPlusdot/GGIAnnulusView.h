//
//  GGIAnnulusView.h
//  MyView
//
//  Created by Sir on 14-10-9.
//  Copyright (c) 2014年 GUOGEE. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface GGIAnnulusView : UIView

//- (void)setAnnulusColors:(NSArray *)colors andAngle:(NSArray*)angles;

- (void)setAnnulusColors:(NSArray *)colors andPercents:(NSArray*)percents;

@end
