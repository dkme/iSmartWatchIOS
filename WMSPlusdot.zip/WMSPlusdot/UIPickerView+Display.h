//
//  UIPickerView+Display.h
//  WMSPlusdot
//
//  Created by Sir on 14-12-29.
//  Copyright (c) 2014年 GUOGEE. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface UIPickerView (Display)

- (void)show:(BOOL)animated;

- (void)hidden:(BOOL)animated;

@end
