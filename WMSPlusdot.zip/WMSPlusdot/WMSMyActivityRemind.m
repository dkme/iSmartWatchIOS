//
//  WMSMyActivityRemind.m
//  WMSPlusdot
//
//  Created by Sir on 14-9-20.
//  Copyright (c) 2014年 GUOGEE. All rights reserved.
//

#import "WMSMyActivityRemind.h"

@implementation WMSMyActivityRemind

@end
