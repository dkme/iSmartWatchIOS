//
//  WMSRightViewController.h
//  WMSPlusdot
//
//  Created by John on 14-8-21.
//  Copyright (c) 2014年 GUOGEE. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface WMSRightViewController : UITableViewController

- (void)resetFirstConnectedConfig;

@end
