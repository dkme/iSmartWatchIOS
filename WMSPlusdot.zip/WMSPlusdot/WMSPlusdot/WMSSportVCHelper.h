//
//  WMSSportVCHelper.h
//  WMSPlusdot
//
//  Created by Sir on 15-1-22.
//  Copyright (c) 2015年 GUOGEE. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface WMSSportVCHelper : NSObject

- (void)updateLabel:(UILabel *)label value:(NSUInteger)value;

@end
