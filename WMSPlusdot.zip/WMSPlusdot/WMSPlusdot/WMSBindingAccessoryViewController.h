//
//  WMSBindingAccessoryViewController.h
//  WMSPlusdot
//
//  Created by John on 14-8-23.
//  Copyright (c) 2014年 GUOGEE. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface WMSBindingAccessoryViewController : UIViewController

@property (assign, nonatomic) int generation;//第一款为1，第二款为2

@end
