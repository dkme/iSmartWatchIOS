//
//  UIImage+Color.h
//  WMSPlusdot
//
//  Created by Sir on 15-1-13.
//  Copyright (c) 2015年 GUOGEE. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface UIImage (Color)

+ (UIImage *)imageFromColor:(UIColor *)color;

@end
