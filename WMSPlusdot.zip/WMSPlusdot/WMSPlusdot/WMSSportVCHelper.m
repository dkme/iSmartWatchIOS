//
//  WMSSportVCHelper.m
//  WMSPlusdot
//
//  Created by Sir on 15-1-22.
//  Copyright (c) 2015年 GUOGEE. All rights reserved.
//

#import "WMSSportVCHelper.h"
#import "WMSContentViewController.h"

@implementation WMSSportVCHelper

- (void)updateLabel:(UILabel *)label value:(NSUInteger)value
{
    
}

@end
