//
//  WMSMacro.m
//  WMSPlusdot
//
//  Created by Sir on 14-9-26.
//  Copyright (c) 2014年 GUOGEE. All rights reserved.
//

#import "WMSMacro.h"

@implementation WMSMacro

@end
