//
//  WMSURLMacro.h
//  WMSPlusdot
//
//  Created by Sir on 14-12-4.
//  Copyright (c) 2014年 GUOGEE. All rights reserved.
//

#define URL_REQUEST_TIMEOUT_INTERVAL        10.f

#define URL_APP_INFO                        @"http://itunes.apple.com/lookup?id＝930839162"

/******************好礼兑换***********************/
#define URL_GIFT_AND_BEANS                  @"http://182.92.157.146:8080/gambler"
#define API_ACTIVITY_LIST                   @"activity/list"
#define API_ACTIVITY_LOGO                   @"image"
#define API_ACTIVITY_RULE                   @"activity/getInfo"
#define API_GIFT_BAG_LIST                   @"giftbag/userlist"
#define API_GIFT_BAG_GETBAG                 @"giftbag/getBag"
#define API_GET_BEAN_RULE                   @"userbean/getBeanExchangeRule"
#define API_USER_GET_BEAN                   @"userbean/saveUserBean"
#define API_USER_BEANS                      @"userbean/getUserBean"

