//
//  WMSMacro.h
//  WMSPlusdot
//
//  Created by Sir on 14-9-26.
//  Copyright (c) 2014年 GUOGEE. All rights reserved.
//

#define WATCH_NAME                  @"plusdot-watch"
#define WATCH_NAME2                 @"plusdout-watch"
#define WATCH_NAME_G2               @"plusdot-watch2"
#define WATCH_NAME_DFU              @"DfuTarg"
#define SCAN_PERIPHERAL_INTERVAL    5.f

#define HUD_SIZE                    CGSizeMake(250, 120)
